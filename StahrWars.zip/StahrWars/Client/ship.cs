﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Client
{
    class Ship
    {
        int row;
        int col;
        PictureBox panCanvas;
        int currentShipAngle;
        public Ship(PictureBox panCanvas, int shipAngle)
        {
            this.panCanvas = panCanvas;
            this.currentShipAngle = shipAngle;
        }

        public string turnNorth()
        {
            if (currentShipAngle != 0)
            {
                currentShipAngle = 0;
                panCanvas.Refresh();
                
                return "rn";
            }
            else
            {
                return "mov:n";
            }
        }
        public string turnEast()
        {
            if (currentShipAngle != 0)
            {
                currentShipAngle = 0;
                panCanvas.Refresh();

                return "re";
            }
            else
            {
                return "mov:e";
            }
        }
        public string turnSouth()
        {
            if (currentShipAngle != 0)
            {
                currentShipAngle = 0;
                panCanvas.Refresh();

                return "rs";
            }
            else
            {
                return "mov:s";
            }
        }
        public string turnWest()
        {
            if (currentShipAngle != 0)
            {
                currentShipAngle = 0;
                panCanvas.Refresh();

                return "rw";
            }
            else
            {
                return "mov:w";
            }
        }

    }
}
